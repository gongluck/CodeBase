Optional plugins for gRPC Core: Modules in this directory extend gRPC Core in
useful ways. All optional code belongs here.

NOTE: The movement of code between lib and ext is an ongoing effort, so this
directory currently contains too much of the core library.
